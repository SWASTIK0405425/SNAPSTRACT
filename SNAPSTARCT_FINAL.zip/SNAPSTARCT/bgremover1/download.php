<?php
/**
 * download.php — streams a previously-generated output image back to the
 * browser as a forced download, then deletes it from /outputs immediately
 * afterwards, so results are one-time-downloadable and don't pile up on disk.
 *
 * Usage: download.php?file=bg_20260715_123456_abcd1234.png
 */

$outputDir = __DIR__ . '/outputs';

function fail($code, $message) {
    http_response_code($code);
    header('Content-Type: text/plain');
    echo $message;
    exit;
}

if (!isset($_GET['file']) || $_GET['file'] === '') {
    fail(400, 'Missing file parameter.');
}

// --- Sanitize the filename to prevent path traversal --------------------------
// basename() strips any directory components (../, /etc/passwd, etc.), so the
// request can never escape the outputs folder no matter what is passed in.
$filename = basename($_GET['file']);

// Extra safety net: only allow the exact filename pattern remove.php generates.
if (!preg_match('/^bg_\d{8}_\d{6}_[a-f0-9]{8}\.png$/', $filename)) {
    fail(400, 'Invalid filename.');
}

$filePath = $outputDir . '/' . $filename;

// realpath() + a startsWith check is a second layer of defense against
// path traversal, in case the pattern check above is ever loosened later.
$realOutputDir = realpath($outputDir);
$realFilePath  = realpath($filePath);

if ($realFilePath === false || $realOutputDir === false || strpos($realFilePath, $realOutputDir) !== 0) {
    fail(404, 'File not found.');
}

if (!is_file($realFilePath)) {
    fail(404, 'File not found.');
}

// --- Stream the file to the browser as a forced download ----------------------
$fileSize = filesize($realFilePath);

header('Content-Description: File Transfer');
header('Content-Type: image/png');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . $fileSize);
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Flush any output buffers so the file data isn't held in memory / mangled.
while (ob_get_level() > 0) {
    ob_end_flush();
}

readfile($realFilePath);

// --- Immediately delete the file now that it's been sent -----------------------
// Note: readfile() has already handed the bytes to PHP's output buffer/socket
// by this point, so deleting here does not truncate what the browser receives.
@unlink($realFilePath);

exit;
